package com.bys.oip.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bys.oip.bean.MyResult;
import com.bys.oip.bean.SysUser;
import com.bys.oip.dao.UserDao;

import net.sf.json.JSONObject;

@RestController
public class UserController {

	private static Log log = LogFactory.getLog(UserController.class);
	@Autowired
	private UserDao userDao;

	@RequestMapping("/register")
	public String add(@ModelAttribute("user") SysUser user, Model model){
		log.info("start to add user!");
		if(userDao.selectUserByName(user.getUserName())!=null)
		{
			return "Exist";
		}
		else
		{
			userDao.addUser(user);
			System.out.println(user.getUserName()+" add success");
			return "RegisterSuccess";
		}
		
	}
	
	@RequestMapping("/query")
//	public MyResult query(){
		public MyResult query(@RequestBody String data, HttpServletRequest request, HttpServletResponse response){	
		log.info("start to query user!");

		JSONObject jo = JSONObject.fromObject(data); 
		String userName = jo.getString("userName");
//		String userName = "guo";
		List<SysUser> searchResult = userDao.searchUserByName(userName);
		log.info(searchResult.size());
		
		MyResult myResult = new MyResult();
		myResult.setCode(0);
		myResult.setMsg("sucess");
		myResult.setList(searchResult);
		myResult.setObj(null);
		
		return myResult;
		
	}
	
	@RequestMapping("/login")
    public String loginControl(@ModelAttribute("user") SysUser user, Model model) {
		 
		log.info("username is "+user.getUserName()==null);
		log.info("password is "+user.getPassword()==null);
		if("".equals(user.getUserName()) || "".equals(user.getPassword()))
		{
			return "Reinput";
		}

		SysUser u = userDao.selectUserByName(user.getUserName());
		if (null != u )
		{
			log.info("user name is xxx"+user.getUserName());
		 	String pass = u.getPassword();
		 	
			if(pass.equals(user.getPassword()))
	        {
	        	return "Main";
	        }
	        else 
	        {
	        	return "Error";
	        }
		}
		else
			return "Error";
    }

	
	@RequestMapping("/back")
	public String select(SysUser user, Model model){
		return "index";
	}
	
	@RequestMapping("/logout")
	public String logout(SysUser user, Model model){
		return "index";
	}
	
}
