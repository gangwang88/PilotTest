package com.bys.oip.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties.Jedis;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bys.oip.util.EmailTextTemplate;
import com.bys.oip.util.EmailUtils;
import com.bys.oip.util.RedisUtil;
import com.bys.oip.util.RestRedisConstant;

import net.sf.json.JSONObject;

@RestController
@RequestMapping("/mail")
public class MailController {
	
	public static Map<String, String> veriCode = new HashMap<String, String>();
	/**
	 * 获取邮箱配置
	 */
	@Value(value = "${email.host-name}")
	public String EMAIL_HOST_NAME;

	@Value(value = "${email.authentication.username}")
	public String EMAIL_AUTHENTICATION_USERNAME;

	@Value(value = "${email.authentication.password}")
	public String EMAIL_AUTHENTICATION_PASSWORD;

	@Value(value = "${email.charset}")
	public String EMAIL_CHARSET;

	@Value(value = "${email.form.mail}")
	public String EMAIL_FORM_MAIL;

	@Value(value = "${email.form.name}")
	public String EMAIL_FORM_NAME;

	@Autowired
	RedisUtil redisUtil;
	/**
	 * 验证码过期时间60s
	 */
	private Integer redisExpire = 60 * 1000;
	
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(MailController.class);
	private static Log log = LogFactory.getLog(MailController.class);
	
    @PostMapping(value = "/send")
    public String sendVerityCode(@RequestBody String rawData)
    {
    	log.info("start to send mail!");

		JSONObject jo = JSONObject.fromObject(rawData); 
		String email = jo.getString("email");
		
		String emailCode = EmailUtils.getNumber();
        //发送验证码
		try 
		{
			EmailUtils.sendEmailCode(EMAIL_HOST_NAME, EMAIL_FORM_MAIL,
			        EMAIL_FORM_NAME, EMAIL_AUTHENTICATION_USERNAME,
			        EMAIL_AUTHENTICATION_PASSWORD, email, EmailTextTemplate.REGISTER_SUBJECT,
			        EmailTextTemplate.REGISTER_CONTENT + emailCode + EmailTextTemplate.CONTENT_SUFFIX);
				
			//Jedis jedis = new Jedis("localhost", 7378);
			
			redisUtil.set(RestRedisConstant.REST_ELOG_REGISTER_EMAIL_CODE_KEY, emailCode, redisExpire);
	        logger.info("Redis存储验证码成功：{}", emailCode);
			
			//veriCode.put("savedCode", emailCode);
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info("验证码发送失败：{}");
			return "failed";
		}
        log.info("验证码发送成功：{}");
    	
		return "验证码已成功发送"; 	
    	
    }
    
    @PostMapping(value = "/verify")
    public String VerityCode(@RequestBody String rawData)
    {
    	log.info("log start to verify mail!");
    	logger.info("logger start to verify mail!");
    	
		JSONObject jo = JSONObject.fromObject(rawData); 
		String code = jo.getString("code");
		
		//String emailCode = veriCode.get("savedCode");
		String emailCode = (String)redisUtil.get(RestRedisConstant.REST_ELOG_REGISTER_EMAIL_CODE_KEY);
		if(code.equals(emailCode))
		{
			logger.info("恭喜恭喜！验证成功：{}",code);
			return "恭喜恭喜！验证成功"; 
		}
		else
		{
			logger.info("Sorry，验证失败：{}",code);
			return "Sorry，验证失败"; 
		}
    	
			
    	
    }
}
