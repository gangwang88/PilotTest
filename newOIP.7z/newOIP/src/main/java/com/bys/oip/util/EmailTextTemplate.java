package com.bys.oip.util;

public class EmailTextTemplate {
	
	public final static String REGISTER_SUBJECT = "Verify Code";
	public final static String REGISTER_CONTENT = "hello, //r this is your verify code: ";
	public final static String CONTENT_SUFFIX = "//r thank you!";

}
