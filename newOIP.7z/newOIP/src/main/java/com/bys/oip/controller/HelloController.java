package com.bys.oip.controller;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.web.server.Http2;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.bys.oip.bean.SysUser;
import com.bys.oip.util.HttpUtils;

@RestController
@RequestMapping("/say")
public class HelloController {
    
    @GetMapping(value = "/test")
    public String defaultView()
    {
    	SysUser su = new SysUser();
    	su.setUserName("tobias");
    	su.setEmail("eliulang@163.com");
    	su.setGroupName("manager");
    	
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put("first", su);
    	map.put("second", su);
    	
    	JSONObject jo = new JSONObject(map);
    	System.out.println(jo.toString());
    	
        return "Error";
    }
    
    @GetMapping(value = "/hello")
    public net.sf.json.JSONObject say(HttpServletRequest request) throws MalformedURLException
    {    	
//    	URL restURL = new URL(url);    	
//    	HttpURLConnection conn = (HttpURLConnection) restURL.openConnection();
//        //请求方式
//        conn.setRequestMethod("POST");
//        //设置是否从httpUrlConnection读入，默认情况下是true; httpUrlConnection.setDoInput(true);
//        conn.setDoOutput(true);
//        //allowUserInteraction 如果为 true，则在允许用户交互（例如弹出一个验证对话框）的上下文中对此 URL 进行检查。
//        conn.setAllowUserInteraction(false);
//        conn.setRequestProperty("token", token);
//        conn.setRequestProperty("Content-type", "application/json");
    	Map<String,String> map = new HashMap<String,String>();
    	map.put("orderNumber", "6589345");
    	JSONObject jo = (JSONObject) JSONObject.toJSON(map);

    	
        HttpUtils http = new HttpUtils();
        // 发送 POST 请求 调用接口 参数1 接口名（项目后 不带/） 参数二 json对象 参数三 request
        net.sf.json.JSONObject response = http.doPost("/query", jo);    	
    	
        return response;
    }
    
}