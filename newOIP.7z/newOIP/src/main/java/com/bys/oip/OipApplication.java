package com.bys.oip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.bys.*")
public class OipApplication {

	public static void main(String[] args) {
		SpringApplication.run(OipApplication.class, args);
	}

}
