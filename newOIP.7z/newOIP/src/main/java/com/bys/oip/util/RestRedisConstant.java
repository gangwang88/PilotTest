package com.bys.oip.util;

public class RestRedisConstant {

	public final static String REST_ELOG_REGISTER_EMAIL_CODE_KEY = "EmailVerifyCode";
}
