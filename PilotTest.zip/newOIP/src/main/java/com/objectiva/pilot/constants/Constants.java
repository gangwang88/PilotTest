package com.objectiva.pilot.constants;

public class Constants {

	public final static String THREE_MONTH_DETAILS = "Three Months Back Statement Details as below:";
	
	public final static String STATEMENT_DETAILS = "The Required Statement Details as below:";
}
