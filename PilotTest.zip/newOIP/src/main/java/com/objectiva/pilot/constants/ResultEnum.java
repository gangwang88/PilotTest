package com.objectiva.pilot.constants;

/**
 * @author TobiasWang
 * 2020/11/16
 */

public enum ResultEnum
{
    CODE_402("402", "密码错误"),
    CODE_403("403", "验证码不正确"), 
    CODE_404("404", "参数不能为空"), 
    CODE_406("406", "订单编号为空"), 
    CODE_407("407", "用户未注冊"),
    CODE_408("408", "物流信息异常"),
    CODE_409("409", "输入参数不正确"), 
    CODE_410("410", "userId为空"),  
    CODE_411("411", "用户不存在"), 
    CODE_413("413", "JSON格式错误"),
    CODE_414("414", "pageNum为空"),
    CODE_415("415", "pageSize为空"),
    SUCCESS("200", "恭喜恭喜！成功登陆");

    private String code;

    private String msg;

    ResultEnum(String code, String msg)
    {
        this.code = code;
        this.msg = msg;
    }

    public String getCode()
    {
        return code;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }
}
