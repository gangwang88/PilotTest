package com.objectiva.pilot.service;

import com.objectiva.pilot.constants.Result;

public interface IStatementTableService
{   
    Result getStatementTableList(String email);
}
