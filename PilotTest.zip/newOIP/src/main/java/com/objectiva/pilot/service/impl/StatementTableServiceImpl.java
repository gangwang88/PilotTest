package com.objectiva.pilot.service.impl;

import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.objectiva.pilot.constants.Constants;
import com.objectiva.pilot.constants.Result;
import com.objectiva.pilot.constants.ResultEnum;
import com.objectiva.pilot.constants.ResultUtil;
import com.objectiva.pilot.dao.StatementDao;
import com.objectiva.pilot.dao.UserDao;
import com.objectiva.pilot.model.SysStatement;
import com.objectiva.pilot.model.dto.DisplayDto;
import com.objectiva.pilot.model.dto.SearchDto;
import com.objectiva.pilot.service.IStatementTableService;
import com.objectiva.pilot.util.CommonUtils;
import com.objectiva.pilot.util.SysStatementUtil;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

/**
 * 
 * @author TobiasWang 2020/11/16
 */
@Service(value = "orderTableService")
public class StatementTableServiceImpl implements IStatementTableService {
	private final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Resource
	private StatementDao statementMapper;

	@Resource
	private UserDao userMapper;

	public Result getStatementTableList(String input) {
		logger.info("->User start to enter service getTableList => input:{}", input);
		JSONObject jsonObj = JSONObject.fromObject(input);
		String searchStartDate = jsonObj.getString("searchStartDate");
		String searchEndDate = jsonObj.getString("searchEndDate");
		String searchStartAmount = jsonObj.getString("searchStartAmount");
		String searchEndAmount = jsonObj.getString("searchEndAmount");
		SearchDto searchDto = new SearchDto(searchStartDate, searchEndDate, searchStartAmount, searchEndAmount);

		List<SysStatement> allStatements = SysStatementUtil.convert(statementMapper.selectAllStatements());

		if (allParamEmpty(searchDto)) {
			logger.error("-> rawData allempty => will return default result for 3 months");
			List<SysStatement> list = allStatements.stream()
					.filter(s -> SysStatementUtil.withinLastThreeMonth(s.getDateField()) == true)
					.collect(Collectors.toList());
			return ResultUtil.OTSResult(findDisplayDto(list),Constants.THREE_MONTH_DETAILS);
		}

		if (!isValid(searchDto)) {
			logger.error("->search wrong parameters error, the detail is：input:{}", searchDto);
			return ResultUtil.error(ResultEnum.CODE_409);
		}
		return conditionalSearch(allStatements, searchDto);
	}

	private List<DisplayDto> findDisplayDto(List<SysStatement> statements) {
		List<DisplayDto> dtos = new ArrayList<DisplayDto>();
		statements.forEach(statement -> {
			DisplayDto dto = new DisplayDto();
			dto.setAccountId(statement.getAccountId());
			dto.setAccountNumber(CommonUtils.toHash(userMapper.findAccountById(statement.getAccountId())));
			dto.setDateField(statement.getDateField().toString());
			dto.setAmount("" + statement.getAmount());
			dtos.add(dto);
		});
		return dtos;
	}
	
	private boolean allParamEmpty(SearchDto dto) {
		return StringUtils.isEmpty(dto.getSearchStartDate()) && StringUtils.isEmpty(dto.getSearchEndDate())
				&& StringUtils.isEmpty(dto.getSearchStartAmount()) && StringUtils.isEmpty(dto.getSearchEndAmount());
	}

	private boolean isValid(SearchDto searchDto) {
		return SysStatementUtil.isDateFormat(searchDto.getSearchStartDate())
				&& SysStatementUtil.isDateFormat(searchDto.getSearchEndDate())
				&& SysStatementUtil.isAmount(searchDto.getSearchStartAmount())
				&& SysStatementUtil.isAmount(searchDto.getSearchEndAmount());
	}

	private Result conditionalSearch(List<SysStatement> allStatements, SearchDto dto) {
		List<SysStatement> list = new ArrayList<SysStatement>();
		if (!StringUtils.isEmpty(dto.getSearchStartDate()) && !StringUtils.isEmpty(dto.getSearchEndDate())) {
			list = allStatements.stream()
					.filter(s -> s.getDateField().isAfter(SysStatementUtil.changeToDate(dto.getSearchStartDate())))
					.filter(s -> s.getDateField().isBefore(SysStatementUtil.changeToDate(dto.getSearchEndDate())))
					.collect(Collectors.toList());
		}
		if ((StringUtils.isEmpty(dto.getSearchStartDate()) || StringUtils.isEmpty(dto.getSearchEndDate()))
				&& !(StringUtils.isEmpty(dto.getSearchStartDate()) && StringUtils.isEmpty(dto.getSearchEndDate()))) {
			list = allStatements.stream().filter(s -> s.getDateField().equals(searchBySingleDate(dto)))
					.collect(Collectors.toList());
		}
		if (!StringUtils.isEmpty(dto.getSearchStartAmount()) && !StringUtils.isEmpty(dto.getSearchEndAmount())) {
			list = allStatements.stream().filter(s -> s.getAmount() > Float.parseFloat(dto.getSearchStartAmount()))
					.filter(s -> s.getAmount() < Float.parseFloat(dto.getSearchEndAmount()))
					.collect(Collectors.toList());
		}
		if ((StringUtils.isEmpty(dto.getSearchStartAmount()) || StringUtils.isEmpty(dto.getSearchEndAmount())) 
				&& !(StringUtils.isEmpty(dto.getSearchStartAmount()) && StringUtils.isEmpty(dto.getSearchEndAmount()))) {
			list = allStatements.stream().filter(s -> s.getAmount() == (searchBySingleAmount(dto)))
					.collect(Collectors.toList());
		}
		return ResultUtil.OTSResult(findDisplayDto(list), Constants.STATEMENT_DETAILS);
	}

	private float searchBySingleAmount(SearchDto dto) {
		return StringUtils.isEmpty(dto.getSearchStartAmount()) ? Float.parseFloat(dto.getSearchStartAmount())
				: Float.parseFloat(dto.getSearchEndAmount());
	}

	private LocalDate searchBySingleDate(SearchDto dto) {
		return StringUtils.isEmpty(dto.getSearchStartDate()) ? SysStatementUtil.changeToDate(dto.getSearchEndDate())
				: SysStatementUtil.changeToDate(dto.getSearchStartDate());
	}
}
