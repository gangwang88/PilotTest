package com.objectiva.pilot.service;

import com.objectiva.pilot.constants.Result;

/**
 * 
 * @author TobiasWang
 *  2020/11/16
 */
public interface IUserService
{
    Result login(String rawData);

}
