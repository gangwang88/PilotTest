package com.objectiva.pilot.util;

import java.util.Date;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.objectiva.pilot.model.SysUser;


public class JWTokenUtils {
	
	//5 minutes
    private static final long EXPIRE_TIME = 5 * 60 * 1000;

    private static final String SECRET = "jwt_secret";
    
    //generate JWT Token
    public static String getToken(String userId) {
        try {
            Date date = new Date(System.currentTimeMillis() + EXPIRE_TIME);
            Algorithm algorithm = Algorithm.HMAC256(SECRET);
            return JWT.create()
                    // 将 user id 保存到 token 里面
                    .withAudience(userId)
                    // 五分钟后token过期
                    .withExpiresAt(date)
                    // token 的密钥
                    .sign(algorithm);
        } catch (Exception e) {
            return null;
        }
    }
    
//    public String getToken(SysUser user) {
//        String token="";
//        token= JWT.create().withAudience(user.getId())
//                .sign(Algorithm.HMAC256(user.getPassword()));
//        return token;
//    }

}
